package obepymes_TestAuto_TestUnitObepyme;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.WebDriver;

import com.itextpdf.layout.Document;

import obepymes_TestAuto_Soriana.baseSetup.SetupTest;
import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;
import obepymes_TestAuto_Soriana.scenesTest.ResumenProgramacionCitaProcess;


	@RunWith(Parameterized.class)

	@FixMethodOrder(MethodSorters.NAME_ASCENDING)
	public class TestUnitResumenProgramacionCita {

		ToolTest creaDoc = new ToolTest();
		DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataSucursalCita.xlsx");
		ResumenProgramacionCitaProcess escenarioResumenProgramacionCita = new ResumenProgramacionCitaProcess();
		SetupTest setupTest = new SetupTest();
		Document documento;
		WebDriver driver;
		public String browser;
		String baseUrl;
		@Parameters(name = "Navegador - {0}")
		public static Collection<String> getBrowser() {

			// String[] navegadores = new String[] { "IE", "CH", "FX" };
			String[] navegadores = new String[] { "CH" };
			// String[] navegadores = new String[] { "FX" };
			// convert the student database into list
			List<String> navList = Arrays.asList(navegadores);

			return navList;

		}


		public TestUnitResumenProgramacionCita(String browser) {

			this.browser = browser;

		}

		@Before
		public void setUp() throws Exception {

			int amb = 2;
			String nav = browser;
			if (browser.equals("IE") == true) {
				baseUrl = excelCont.getData(0, amb, 6);
			}
			if (browser.equals("CH") == true) {
				baseUrl = excelCont.getData(0, amb, 6);
			}
			if (browser.equals("CHV") == true) {
				baseUrl = excelCont.getData(0, amb, 6);
			}
			if (browser.equals("FX") == true) {
				baseUrl = excelCont.getData(0, amb, 6);
			}
			if (browser.equals("CHL") == true) {
				baseUrl = excelCont.getData(0, amb, 6);
			}
			if (browser.equals("FXL") == true) {
				baseUrl = excelCont.getData(0, amb, 6);
			}
			driver = setupTest.RunNav(nav, baseUrl);

		}

		@After
		public void tearDown() throws Exception {
			escenarioResumenProgramacionCita.PdfDoc().close();
			driver.close();
			driver.quit();
		}

		@Test
		public void CP01_ResumenProgramacion_PFAE() throws Exception {
			documento = creaDoc.pdfComplet(1, 1);
			escenarioResumenProgramacionCita.ResumenProgramacionCitaProceso(driver, 1, 1, documento);
			assertEquals(true, escenarioResumenProgramacionCita.ResultadoPrueba());
		}

	}
