package obepymes_TestAuto_Soriana.scenesTest;

import org.openqa.selenium.WebDriver;


import com.itextpdf.layout.Document;

import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;
import obepymes_TestAuto_Soriana.pageObjects.SucursalCitaPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class SucursalCitaProcess {

	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosProcess escenarioPruebaDatos = new DatosBasicosProcess();
	CedulaRfcProcess escenarioCedulaRfc = new CedulaRfcProcess();
	IdentificacionOficialProcess escenarioIdentificacionOficial = new IdentificacionOficialProcess();
	ComprobanteDomicilioProcess escenarioComprobanteDomicilio = new ComprobanteDomicilioProcess();
	LocalizacionSucursalProcess  escenarioLocalizacionSucursal = new LocalizacionSucursalProcess();
	SucursalCitaPage elementsSucursalCita = new SucursalCitaPage();
	
	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataSucursalCita.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void SucursalCitaProceso(WebDriver driver, int j, int i, Document documento) throws Exception {

		
		String casoPrueba = excelCont.getData(j, i, 0);
		String numerodia = excelCont.getData(j, i, 3); 
		try {

			escenarioLocalizacionSucursal.LocalizacionSucursalProceso(driver, j, i, docPdf);


if(numerodia.equals("1"))
{
creaDoc.TimeMedium();
elementsSucursalCita.WaitFechaCita1echacita1(driver);
elementsSucursalCita.FechaCita1(driver).click();
creaDoc.TimeFast();
}
if(numerodia.equals("2"))
{
creaDoc.TimeMedium();
elementsSucursalCita.WaitFechaCita1echacita2(driver);
elementsSucursalCita.FechaCita1(driver).click();
creaDoc.TimeFast();
}
if(dia.equals("3"))
{
creaDoc.TimeMedium();
elementsSucursalCita.WaitFechaCita1echacita3(driver);
elementsSucursalCita.FechaCita3(driver).click();
creaDoc.TimeFast();
}

// asi hasta el 10



if(horario.equals("1"))
{
creaDoc.TimeMedium();
elementsSucursalCita.WaitHora1(driver);
elementsSucursalCita.Hora1(driver).click();
creaDoc.TimeFast();
}

if(horario.equals("2"))
{
creaDoc.TimeMedium();
elementsSucursalCita.WaitHora2(driver);
elementsSucursalCita.Hora1(driver).click();
creaDoc.TimeFast();
}

if(horario.equals("3"))
{
creaDoc.TimeMedium();
elementsSucursalCita.WaitHora3(driver);
elementsSucursalCita.Hora3(driver).click();
creaDoc.TimeFast();
}
// asi hasta el 8

	

			creaDoc.ObtenerEvidencia(driver, docPdf, "eligio su horario y fecha de cita", casoPrueba);

			creaDoc.Timeload();
			resultado = true;

		} catch (Exception e) {

			creaDoc.ObtenerEvidencia(driver, docPdf,
					"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
			resultado = false;
		}

	}

	public boolean ResultadoPrueba() {
		return resultado;
	}

	public Document PdfDoc() {

		return docPdf;
	}
}
