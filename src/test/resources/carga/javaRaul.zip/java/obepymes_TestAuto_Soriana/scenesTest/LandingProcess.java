package obepymes_TestAuto_Soriana.scenesTest;


import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import com.itextpdf.layout.Document;
import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;
import obepymes_TestAuto_Soriana.pageObjects.LandingPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class LandingProcess {

	LandingPage elementsLanding = new LandingPage();
	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataDbasicos.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void TramitarCreditoProceso(WebDriver driver, int j, int i, Document documento) throws Exception {
		docPdf = documento;
		String casoPrueba = excelCont.getData(j, i, 0);

		if (valDatos.ValLanding(driver) == true) {
			try {

				elementsLanding.WaitbtnContinue(driver);
				elementsLanding.btnContinue(driver).sendKeys(Keys.TAB);
				creaDoc.TimeFast();
				elementsLanding.btnContinue(driver).click();
				creaDoc.ObtenerEvidencia(driver, docPdf, "muestra aviso de privacidad", casoPrueba);
				elementsLanding.WaitacceptTermsCheckLabel(driver);
				elementsLanding.acceptTermsCheckLabel(driver).click();
				creaDoc.ObtenerEvidencia(driver, docPdf, "clic en check aviso de privacidad", casoPrueba);
				elementsLanding.WaitacceptTemrs(driver);
				elementsLanding.acceptTemrs(driver).click();
				creaDoc.ObtenerEvidencia(driver, docPdf, "muestra pantalla de datos basicos", casoPrueba);

				resultado = true;

			} catch (Exception e) {

				creaDoc.ObtenerEvidencia(driver, docPdf,
						"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
				resultado = false;

			}

		} else {
			creaDoc.ObtenerEvidencia(driver, docPdf,
					"No se encontraron los elementos suficientes para realizar la prueba", casoPrueba);
			resultado = false;
		}
	}

	public boolean ResultadoPrueba() {
		return resultado;
	}

	public Document PdfDoc() {

		return docPdf;
	}

}
