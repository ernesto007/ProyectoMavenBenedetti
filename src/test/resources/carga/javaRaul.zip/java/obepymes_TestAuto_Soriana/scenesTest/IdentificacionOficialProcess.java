package obepymes_TestAuto_Soriana.scenesTest;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.itextpdf.layout.Document;
import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;
import obepymes_TestAuto_Soriana.pageObjects.IdentificacionOficialPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class IdentificacionOficialProcess {

	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosProcess escenarioPruebaDatos = new DatosBasicosProcess();
	CedulaRfcProcess escenarioCedulaRfc = new CedulaRfcProcess();
	IdentificacionOficialPage elementsIdentificacionOficial = new IdentificacionOficialPage();

	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataIdentificacionOficial.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void IdentificacionOficialProceso(WebDriver driver, int j, int i, Document documento) throws Exception {

		String casoPrueba = excelCont.getData(j, i, 0);
		String ine = excelCont.getData(j, i, 1);
		String ife = excelCont.getData(j, i, 2);
		String pasaporte = excelCont.getData(j, i, 3);
		String estadoCivil = excelCont.getData(j, i, 4);
		String vigenciaAnual = excelCont.getData(j, i, 5);
		String reverso = excelCont.getData(j, i, 6);
		String vigenciaMes = excelCont.getData(j, i, 7);

		docPdf = documento;
		try {

			escenarioCedulaRfc.CedulaRfcProceso(driver, j, i, docPdf);

			if(ife.equals("no")&& pasaporte.equals("no")){
				
			
			elementsIdentificacionOficial.WaitcargarIne(driver);
			elementsIdentificacionOficial.cargarIne(driver).click();

			creaDoc.TimeFast();
			creaDoc.Paste(ine);
			creaDoc.TimeMedium();
			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga Ine Frente ", casoPrueba);
			creaDoc.TimeMedium();
			elementsIdentificacionOficial.WaitcargarIneReverso(driver);
			elementsIdentificacionOficial.cargarIneReverso(driver).click();

			creaDoc.TimeFast();

			creaDoc.Paste(reverso);

			creaDoc.TimeMedium();
			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga INE", casoPrueba);
			creaDoc.TimeMedium();
			
			elementsIdentificacionOficial.WaitcivilStatusSelect(driver);
			new Select(elementsIdentificacionOficial.civilStatusSelect(driver)).selectByVisibleText(estadoCivil);

			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);

			elementsIdentificacionOficial.WaitvaliditySelect(driver);
			new Select(elementsIdentificacionOficial.validitySelect(driver)).selectByVisibleText(vigenciaAnual);

			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);
			
			elementsIdentificacionOficial.WaitbtnContinue(driver);
			elementsIdentificacionOficial.btnContinue(driver).click();

			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);
			
			resultado = true;
		}
//CARGAR INE
		if (ine.equals("no") && pasaporte.equals("no")) {

			elementsIdentificacionOficial.WaitcargarIfe(driver);
			elementsIdentificacionOficial.cargarIfe(driver).click();

			creaDoc.TimeFast();

			creaDoc.Paste(ife);

			creaDoc.TimeMedium();
			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga INE", casoPrueba);
			creaDoc.TimeMedium();

			elementsIdentificacionOficial.WaitcargarIneReverso(driver);
			elementsIdentificacionOficial.cargarIneReverso(driver).click();

			creaDoc.TimeFast();

			creaDoc.Paste(reverso);

			creaDoc.TimeMedium();
			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga IFE", casoPrueba);
			creaDoc.TimeMedium();
			
			elementsIdentificacionOficial.WaitcivilStatusSelect(driver);
			new Select(elementsIdentificacionOficial.civilStatusSelect(driver)).selectByVisibleText(estadoCivil);

			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);

			elementsIdentificacionOficial.WaitvaliditySelect(driver);
			new Select(elementsIdentificacionOficial.validitySelect(driver)).selectByVisibleText(vigenciaAnual);

			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);
			
			elementsIdentificacionOficial.WaitbtnContinue(driver);
			elementsIdentificacionOficial.btnContinue(driver).click();

			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);
			
			resultado = true;
		}
//CARGAR PASAPORTE
		if (ine.equals("no") && ife.equals("no")) {

			elementsIdentificacionOficial.WaitcargarPasaporte(driver);
			elementsIdentificacionOficial.cargarPasaporte(driver).click();

			creaDoc.TimeFast();

			creaDoc.Paste(pasaporte);

			creaDoc.TimeMedium();
			creaDoc.ObtenerEvidencia(driver, docPdf, "Carga PASAPORTE", casoPrueba);
			creaDoc.TimeMedium();
		

			elementsIdentificacionOficial.WaitcivilStatusSelect(driver);
		new Select(elementsIdentificacionOficial.civilStatusSelect(driver)).selectByVisibleText(estadoCivil);

		creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);

		elementsIdentificacionOficial.WaitvaliditySelect(driver);
		new Select(elementsIdentificacionOficial.validitySelect(driver)).selectByVisibleText(vigenciaAnual);

		creaDoc.ObtenerEvidencia(driver, docPdf, "Carga a�o vigencia", casoPrueba);
		
		elementsIdentificacionOficial.WaitmonthValiditySelect(driver);
		new Select(elementsIdentificacionOficial.monthValiditySelect(driver)).selectByVisibleText(vigenciaMes);
		
		creaDoc.ObtenerEvidencia(driver, docPdf, "Carga mes vigencia", casoPrueba);
		
		elementsIdentificacionOficial.WaitbtnContinue(driver);
		elementsIdentificacionOficial.btnContinue(driver).click();

		creaDoc.ObtenerEvidencia(driver, docPdf, "Carga estado civil", casoPrueba);
		
		resultado = true;
		}

	} catch (Exception e) {

		creaDoc.ObtenerEvidencia(driver, docPdf,
				"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
		resultado = false;
	}

}

public boolean ResultadoPrueba() {
	return resultado;
}

public Document PdfDoc() {

	return docPdf;
}

}
