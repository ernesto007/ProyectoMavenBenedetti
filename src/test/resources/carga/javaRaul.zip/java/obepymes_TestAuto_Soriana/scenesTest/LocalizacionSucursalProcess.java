package obepymes_TestAuto_Soriana.scenesTest;

import org.openqa.selenium.WebDriver;


import com.itextpdf.layout.Document;

import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;

import obepymes_TestAuto_Soriana.pageObjects.LocalizacionSucursalPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class LocalizacionSucursalProcess {

	
	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosProcess escenarioPruebaDatos = new DatosBasicosProcess();
	CedulaRfcProcess escenarioCedulaRfc = new CedulaRfcProcess();
	IdentificacionOficialProcess escenarioIdentificacionOficial = new IdentificacionOficialProcess(); 
	ComprobanteDomicilioProcess escenerioComprobanteDomicilio = new ComprobanteDomicilioProcess();
	LocalizacionSucursalPage elementsLocalizacionSucursal = new LocalizacionSucursalPage();
	
	
	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataLocalizacionSucursal.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void LocalizacionSucursalProceso(WebDriver driver, int j, int i, Document documento) throws Exception {

		String casoPrueba = excelCont.getData(j, i, 0);
		String escribeciudad = excelCont.getData(j, i, 1);
		
		
		docPdf = documento;
		try {

			
			escenerioComprobanteDomicilio.ComprobanteDomicilioProceso(driver, j, i, docPdf);

			elementsLocalizacionSucursal.WaitBuscaSucursal(driver);
			elementsLocalizacionSucursal.BuscaSucursal(driver).sendKeys(escribeciudad);
			elementsLocalizacionSucursal.WaitSeleccionarSucursalFactura(driver);
			elementsLocalizacionSucursal.SeleccionarSucursal(driver).click();
			elementsLocalizacionSucursal.WaitSeleccionarSucursalFactura(driver);
			elementsLocalizacionSucursal.SeleccionarSucursal(driver).click();
			elementsLocalizacionSucursal.WaitBotonDeContinuar(driver);
			elementsLocalizacionSucursal.BotonDeContinuar(driver).click();
			
			
			

			creaDoc.Timeload();
			resultado = true;

		} catch (Exception e) {

			creaDoc.ObtenerEvidencia(driver, docPdf,
					"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
			resultado = false;
		}

	}

	public boolean ResultadoPrueba() {
		return resultado;
	}

	public Document PdfDoc() {

		return docPdf;
}
}
