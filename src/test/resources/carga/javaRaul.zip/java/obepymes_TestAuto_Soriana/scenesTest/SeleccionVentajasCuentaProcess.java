package obepymes_TestAuto_Soriana.scenesTest;

import org.openqa.selenium.WebDriver;

import com.itextpdf.layout.Document;

import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;

import obepymes_TestAuto_Soriana.pageObjects.SeleccionVentajasCuentaPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class SeleccionVentajasCuentaProcess {


	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosProcess escenarioPruebaDatos = new DatosBasicosProcess();
	CedulaRfcProcess escenarioCedulaRfc = new CedulaRfcProcess();
	IdentificacionOficialProcess escenarioIdentificacionOficial = new IdentificacionOficialProcess();
	ComprobanteDomicilioProcess escenerioComprobanteDomiciilio = new ComprobanteDomicilioProcess();
	LocalizacionSucursalProcess  escenarioLocalizacionSucursal = new LocalizacionSucursalProcess();
	SucursalCitaProcess esenarioSucursalCita = new SucursalCitaProcess();
	SeleccionVentajasCuentaPage elementsSeleccionVentajasCuenta = new SeleccionVentajasCuentaPage();
	
	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataSucursalCita.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void SeleccionVentajasCuentaProceso(WebDriver driver, int j, int i, Document documento) throws Exception {

		String casoPrueba = excelCont.getData(j, i, 0);
		
		try {

			esenarioSucursalCita.SucursalCitaProceso(driver, j, i, docPdf);

			elementsSeleccionVentajasCuenta.WaitCheckCreditoPyme(driver);
			elementsSeleccionVentajasCuenta.CheckCreditoPyme(driver).click();
			
			elementsSeleccionVentajasCuenta.WaitCheckTarjetaCredito(driver);
			elementsSeleccionVentajasCuenta.CheckTarjetaCredito(driver).click();
			
			elementsSeleccionVentajasCuenta.WaitCheckTerminalPuntoVenta(driver);
			elementsSeleccionVentajasCuenta.CheckTerminalPuntoVenta(driver).click();
			
			elementsSeleccionVentajasCuenta.WaitCheckNomina(driver);
			elementsSeleccionVentajasCuenta.CheckNomina(driver).click();
			
			elementsSeleccionVentajasCuenta.WaitCheckPagoImpuestos(driver);
			elementsSeleccionVentajasCuenta.CheckPagoImpuestos(driver).click();
			
			elementsSeleccionVentajasCuenta.WaitBotonContinuar(driver);
			elementsSeleccionVentajasCuenta.BotonContinuar(driver).click();
			
			

			creaDoc.ObtenerEvidencia(driver, docPdf, "Avanzamos a siguiente pagina", casoPrueba);

			creaDoc.Timeload();
			resultado = true;

		} catch (Exception e) {

			creaDoc.ObtenerEvidencia(driver, docPdf,
					"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
			resultado = false;
		}

	}

	public boolean ResultadoPrueba() {
		return resultado;
	}

	public Document PdfDoc() {

		return docPdf;
	}
}
