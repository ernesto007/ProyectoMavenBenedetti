package obepymes_TestAuto_Soriana.scenesTest;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import com.itextpdf.layout.Document;
import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;
import obepymes_TestAuto_Soriana.pageObjects.CedulaRfcPage;

import obepymes_TestAuto_Soriana.validation.validationLanding;

public class CedulaRfcProcess {

	
	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosProcess escenarioPruebaDatos = new DatosBasicosProcess();
	CedulaRfcPage elementsCedulaRfc = new CedulaRfcPage();
	
	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataCedulaRfc.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void CedulaRfcProceso(WebDriver driver, int j, int i, Document documento) throws Exception {

		String casoPrueba = excelCont.getData(j, i, 0);
		String archivoRfc = excelCont.getData(j, i, 1);
		String actividadEconomica = excelCont.getData(j, i, 2);
		String curp = excelCont.getData(j, i, 3);
		String codigoPostal = excelCont.getData(j, i, 4);

		docPdf = documento;
		try {

			
			escenarioPruebaDatos.DatosBasicosProceso(driver, j, i, docPdf);

			elementsCedulaRfc.WaitImagenCedulaRfc(driver);
			elementsCedulaRfc.ImagenCedulaRfc(driver).click();

			creaDoc.TimeFast();
			creaDoc.Paste(archivoRfc);
			creaDoc.TimeMedium();
			creaDoc.ObtenerEvidencia(driver, docPdf, "Cargo la cedula RFC", casoPrueba);
			elementsCedulaRfc.ImagenCedulaRfc(driver).sendKeys(archivoRfc);
			creaDoc.TimeMedium();
			
			elementsCedulaRfc.WaitActividadEconomica(driver);
			elementsCedulaRfc.ActividadEconomica(driver).sendKeys(actividadEconomica);
			elementsCedulaRfc.ActividadEconomica(driver).sendKeys(Keys.TAB);
			creaDoc.ObtenerEvidencia(driver, docPdf, "Ingreso la Actividad Economica", casoPrueba);
			
			elementsCedulaRfc.WaitCurp(driver);
			elementsCedulaRfc.Curp(driver).sendKeys(curp);
			creaDoc.ObtenerEvidencia(driver, docPdf, "inseto curp", casoPrueba);
			
			elementsCedulaRfc.WaitModalAceptaCurp(driver);
			elementsCedulaRfc.ModalAceptaCurp(driver).click();
			creaDoc.ObtenerEvidencia(driver, docPdf, "verifico curp", casoPrueba);
			
			elementsCedulaRfc.WaitCodigoPostal(driver);
			elementsCedulaRfc.CodigoPostal(driver).sendKeys(codigoPostal);
			elementsCedulaRfc.CodigoPostal(driver).sendKeys(Keys.TAB);
			
			creaDoc.ObtenerEvidencia(driver, docPdf, "ingresa codigo postal", casoPrueba);

			elementsCedulaRfc.WaitBotoncontinuar(driver);
			elementsCedulaRfc.BotonContinuar(driver).click();
			
			creaDoc.ObtenerEvidencia(driver, docPdf, "Avanzo a pag siguiente Identificion Ofiical ", casoPrueba);

			creaDoc.Timeload();
			resultado = true;

		} catch (Exception e) {

			creaDoc.ObtenerEvidencia(driver, docPdf,
					"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
			resultado = false;
		}

	}

	public boolean ResultadoPrueba() {
		return resultado;
	}

	public Document PdfDoc() {

		return docPdf;
	}
}
