package obepymes_TestAuto_Soriana.scenesTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.itextpdf.layout.Document;

import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;

import obepymes_TestAuto_Soriana.pageObjects.ComprobanteDomicilioPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class ComprobanteDomicilioProcess {

	
	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosProcess escenarioPruebaDatos = new DatosBasicosProcess();
	CedulaRfcProcess escenarioCedulaRfc = new CedulaRfcProcess();
	IdentificacionOficialProcess escenarioIdentificacionOficial = new IdentificacionOficialProcess(); 
	ComprobanteDomicilioPage elementsComprobanteDomicilio = new ComprobanteDomicilioPage();
	

	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataComprobanteDomicilio.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void ComprobanteDomicilioProceso(WebDriver driver, int j, int i, Document documento) throws Exception {

		String casoPrueba = excelCont.getData(j, i, 0);
		String reciboBanco= excelCont. getData(j,i,1);
		String reciboLuz =excelCont. getData(j,i,2);
		String reciboTel =excelCont. getData(j,i,3);			
		String ultimoMes = excelCont.getData(j, i, 4);
		String situacionDom = excelCont.getData(j, i, 5);
		String codigoPostal = excelCont.getData(j, i, 6);
		String asentamiento = excelCont.getData(j, i, 7);
		String colonia = excelCont.getData(j, i, 8);
		String vialidad = excelCont.getData(j, i, 9);
		String calle = excelCont.getData(j, i, 10);
		String noExt = excelCont.getData(j, i, 11);
		String noInt= excelCont.getData(j, i, 12);
		String entre = excelCont.getData(j, i, 13);
		String yEntre = excelCont.getData(j, i, 14);
		
		
		
		

		docPdf = documento;
		try {
			escenarioIdentificacionOficial.IdentificacionOficialProceso(driver, j, i, docPdf);

			if(reciboLuz.equals("no")&& reciboTel.equals("no")){
				
				
				elementsComprobanteDomicilio.WaitComprobanteDomicilioEstado(driver);
				elementsComprobanteDomicilio.ComprobanteDomicilioEstado(driver).click();

				creaDoc.TimeFast();
				creaDoc.Paste(reciboBanco);
				creaDoc.TimeMedium();
				creaDoc.ObtenerEvidencia(driver, docPdf, "Carga Estado de cuenta bancario ", casoPrueba);
				creaDoc.TimeMedium();
				
				
			
				
				resultado = true;
			}
	//CARGAR RECIBO LUZ
			if (reciboTel.equals("no") && reciboBanco.equals("no")) {

				elementsComprobanteDomicilio.WaitComprobanteDomicilioLuz(driver);
				elementsComprobanteDomicilio.ComprobanteDomicilioLuz(driver).click();

				creaDoc.TimeFast();

				creaDoc.Paste(reciboLuz);

				creaDoc.TimeMedium();
				creaDoc.ObtenerEvidencia(driver, docPdf, "Carga combrobante de Luz", casoPrueba);
				creaDoc.TimeMedium();

				
				
				resultado = true;
			}
	//CARGAR RECIBO TEL
			if (reciboBanco.equals("no") && reciboLuz.equals("no")) {

				elementsComprobanteDomicilio.WaitComprobanteDomicilioTel(driver);
				elementsComprobanteDomicilio.ComprobanteDomicilioTel(driver).click();

				creaDoc.TimeFast();

				creaDoc.Paste(reciboTel);

				creaDoc.TimeMedium();
				creaDoc.ObtenerEvidencia(driver, docPdf, "Carga combrobante de Telefono", casoPrueba);
				creaDoc.TimeMedium();
			
			}
			
			elementsComprobanteDomicilio.WaitUltimoMesFactura(driver);
			new Select(elementsComprobanteDomicilio.UltimoMesFactura(driver)).selectByVisibleText(ultimoMes);
			elementsComprobanteDomicilio.WaitSituacionCasa(driver);
			new Select(elementsComprobanteDomicilio.SituacionCasa(driver)).selectByVisibleText(situacionDom);
			
			elementsComprobanteDomicilio.WaitCodigoPostalEmpresa(driver);
			elementsComprobanteDomicilio.CodigoPostalEmpresa(driver).sendKeys(codigoPostal);
			
			elementsComprobanteDomicilio.WaitAsentamiento(driver);
			new Select(elementsComprobanteDomicilio.Asentamiento(driver)).selectByVisibleText(asentamiento);
			
			elementsComprobanteDomicilio.WaitColonia(driver);
			new Select(elementsComprobanteDomicilio.Colonia(driver)).selectByVisibleText(colonia);
			
			elementsComprobanteDomicilio.WaitVialidad(driver);
			new Select(elementsComprobanteDomicilio.Vialidad(driver)).selectByVisibleText(vialidad);
			
			elementsComprobanteDomicilio.WaitCalle(driver);
			elementsComprobanteDomicilio.Calle(driver).sendKeys(calle);
			
			elementsComprobanteDomicilio.WaitNumExt(driver);
			elementsComprobanteDomicilio.NumExt(driver).sendKeys(noExt);
			
			elementsComprobanteDomicilio.WaitNumInt(driver);
			elementsComprobanteDomicilio.NumInt(driver).sendKeys(noInt);
			
			elementsComprobanteDomicilio.WaitEntreCalle(driver);			
			elementsComprobanteDomicilio.EntreCalle(driver).sendKeys(entre);
			
			elementsComprobanteDomicilio.WaitYentreCalle(driver);			
			elementsComprobanteDomicilio.YentreCalle(driver).sendKeys(yEntre);
			
			elementsComprobanteDomicilio.WaitBotonRegresar(driver);
			elementsComprobanteDomicilio.BotonRegresar(driver).click();
			elementsComprobanteDomicilio.WaitBotonVolver(driver);
			elementsComprobanteDomicilio.BotonVolver(driver).click();
			
			elementsComprobanteDomicilio.WaitBotoncontinuar(driver);
			elementsComprobanteDomicilio.Botoncontinuar(driver).click();
			
			
			creaDoc.ObtenerEvidencia(driver, docPdf, "ingresa codigo postal", casoPrueba);

			creaDoc.Timeload();
			resultado = true;
			

		}
			catch (Exception e) {

			creaDoc.ObtenerEvidencia(driver, docPdf,
					"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
			resultado = false;
		}

	}

	public boolean ResultadoPrueba() {
		return resultado;
	}

	public Document PdfDoc() {

		return docPdf;
	}
}

