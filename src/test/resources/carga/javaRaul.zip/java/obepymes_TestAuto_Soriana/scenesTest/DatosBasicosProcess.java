package obepymes_TestAuto_Soriana.scenesTest;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.itextpdf.layout.Document;
import obepymes_TestAuto_Soriana.commonTest.ToolTest;
import obepymes_TestAuto_Soriana.daoExcel.DaoExcel;
import obepymes_TestAuto_Soriana.pageObjects.DatosBasicosPage;
import obepymes_TestAuto_Soriana.pageObjects.LandingPage;
import obepymes_TestAuto_Soriana.validation.validationLanding;

public class DatosBasicosProcess {

	LandingPage elementsLanding = new LandingPage();
	LandingProcess escenarioPrueba = new LandingProcess();
	DatosBasicosPage elementsDatosBasicos = new DatosBasicosPage();
	
	ToolTest creaDoc = new ToolTest();
	DaoExcel excelCont = new DaoExcel("src/test/resources/TestDataDbasicos.xlsx");
	String validalong = null;
	validationLanding valDatos = new validationLanding();
	Boolean resultado;
	Document docPdf = null;

	public void DatosBasicosProceso(WebDriver driver, int j, int i,Document documento) throws Exception {

		String casoPrueba = excelCont.getData(j, i, 0);
		String rfc=excelCont.getData(j, i, 1);
		String compa�ia=excelCont.getData(j, i, 2);
		String celular=excelCont.getData(j, i, 3);
		String aPaterno=excelCont.getData(j, i, 4);
		String aMaterno=excelCont.getData(j, i, 5);
		String nombre=excelCont.getData(j, i, 6);
		String email=excelCont.getData(j, i, 7);
		String email2=excelCont.getData(j, i, 8);
		docPdf=documento;
		try {
			
			escenarioPrueba.TramitarCreditoProceso(driver, j, i,docPdf);
			
			elementsDatosBasicos.Waitrfc(driver);
			elementsDatosBasicos.rfc(driver).sendKeys(rfc);
			
			elementsDatosBasicos.WaitcompanySelect(driver);
			new Select(elementsDatosBasicos.companySelect(driver)).selectByVisibleText(compa�ia);
			
			elementsDatosBasicos.WaitphoneNumberComplete(driver);
			elementsDatosBasicos.phoneNumberComplete(driver).sendKeys(celular);
			creaDoc.ObtenerEvidencia(driver, docPdf, "Datos de Contacto",
					casoPrueba);
			elementsDatosBasicos.WaitsendSecurityCode(driver);
			elementsDatosBasicos.sendSecurityCode(driver).click();
			creaDoc.ObtenerEvidencia(driver, docPdf, "envia mensaje de correo",
					casoPrueba);
			elementsDatosBasicos.WaitbtnModalAccept(driver);
			elementsDatosBasicos.btnModalAccept(driver).click();
			creaDoc.ObtenerEvidencia(driver, docPdf, "muestra el campo de codigo seguridad",
					casoPrueba);
			
			creaDoc.TimeMedium();
			String codeValue =elementsDatosBasicos.hdnCodeValue(driver).getAttribute("value");
			
			elementsDatosBasicos.WaitsecurityCode(driver);
			elementsDatosBasicos.securityCode(driver).sendKeys(codeValue);
			
			creaDoc.TimeMedium();
			elementsDatosBasicos.WaitapellidoPaterno(driver);
			elementsDatosBasicos.apellidoPaterno(driver).sendKeys(aPaterno);
			
			elementsDatosBasicos.WaitapellidoMaterno(driver);
			elementsDatosBasicos.apellidoMaterno(driver).sendKeys(aMaterno);
			
			elementsDatosBasicos.Waitnombre(driver);
			elementsDatosBasicos.nombre(driver).sendKeys(nombre);
			
			elementsDatosBasicos.Waitemail(driver);
			elementsDatosBasicos.email(driver).sendKeys(email);
			
			elementsDatosBasicos.Waitemail2(driver);
			elementsDatosBasicos.email2(driver).sendKeys(email2);
			
			creaDoc.ObtenerEvidencia(driver, docPdf, "Datos de basicos",
					casoPrueba);
			elementsDatosBasicos.WaitbtnContinue(driver);
			elementsDatosBasicos.btnContinue(driver).click();
			creaDoc.ObtenerEvidencia(driver, docPdf, "muestra pantalla de identificacion oficial",
					casoPrueba);
			creaDoc.Timeload();
			resultado = true;
			
		} catch (Exception e) {

			creaDoc.ObtenerEvidencia(driver, docPdf,
					"se tardo demasiado en cargar o no se encontro el elemento revisar. Error  " + e, casoPrueba);
			resultado = false;
		}

	}
	
	public boolean ResultadoPrueba() {
		return resultado;
	}
	
	public Document PdfDoc() {

		return docPdf;
	}
}
