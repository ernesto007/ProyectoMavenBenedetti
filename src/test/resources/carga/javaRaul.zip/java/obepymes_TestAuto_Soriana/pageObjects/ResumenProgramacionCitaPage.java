package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ResumenProgramacionCitaPage {

	public static WebElement element = null;
	int secons = 20;

	// TE ARROJA UN RESUMEN DE TU CITA PROGRAMADA CON EL NOMBRE D ETU EJECUTIVO A ATENDER
	//public WebElement ResumenCita(WebDriver driver) {
		//element = driver.findElement(By.xpath("/html/body/div[4]/div/div[2]/div[3]/div/div"));
		//return element;
	//}

	// WAIT
	//public void WaitResumenCita(WebDriver driver) {
		//WebDriverWait wait = new WebDriverWait(driver, secons);
		//element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[4]/div/div[2]/div[3]/div/div")));
	//}

	// BOTON DE ACEPTAR RESUMEN DE CITA
	public WebElement BotonAceptoResumenCita(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnContinuar']"));
		return element;
	}

	// WAIT
	public void WaitBotonAceptoResumenCita(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnContinuar']")));
	}

}
