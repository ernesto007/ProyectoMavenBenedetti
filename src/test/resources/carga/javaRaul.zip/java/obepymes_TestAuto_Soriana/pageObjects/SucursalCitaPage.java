package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SucursalCitaPage {

	public static WebElement element = null;
	int secons = 20;

	// SELECCIONA ENTRE LOS DIAS HABILES CUANDO QUIERES LA FECHA DE TU CITA
	public WebElement FechaCita1(WebDriver driver) {
		element = driver.findElement(By.id("day_1"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitFechacita1(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("day_1")));
	}

		// SELECCIONA ENTRE LOS DIAS HABILES CUANDO QUIERES LA FECHA DE TU CITA
	public WebElement FechaCita2(WebDriver driver) {
		element = driver.findElement(By.id("day_2"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitFechacita2(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("day_2")));
	}

	// SELECCIONA ENTRE EL HORARIO DE ATENCION EN LA SUCURSAL 
	public WebElement HorarioCita(WebDriver driver) {
		element = driver.findElement(By.id("hour_1"));
		return element;
	}

	// WAIT
	public void WaitHorarioCita(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.id("hour_1")));
	}

	// BOTON DE ENVIO PROGRAMACION CITA
	public WebElement BotonEnvioProgramacionCita(WebDriver driver) {
		element = driver.findElement(By.id("btnDefinitiveReserve"));
		return element;
	}

	// WAIT
	public void WaitBotonEnvioProgramacionCita(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnDefinitiveReserve")));
	}

}
