package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IdentificacionOficialPage {

	public static WebElement element = null;
	int secons = 20;

	// CARGAR CEDULA INE
		public WebElement cargarIne(WebDriver driver) {
			element = driver.findElement(By.xpath("//*[@id='radio-toggle']/label[1]/span"));
			return element;
		}
		
		// WAIT
		public void WaitcargarIne(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='radio-toggle']/label[1]/span")));
		}
		
		// CARGAR CEDULA REVERSO
		public WebElement cargarIneReverso(WebDriver driver) {
			element = driver.findElement(By.xpath("//*[@id='helperTarget02']/div/div[1]"));
			return element;
		}
		
		// WAIT
		public void WaitcargarIneReverso(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='helperTarget02']/div/div[1]")));
		}
		

		
		// CARGAR CEDULA IFE
		public WebElement cargarIfe(WebDriver driver) {
			element = driver.findElement(By.xpath("//*[@id='radio-toggle']/label[2]/span"));
			return element;
		}
		
		// WAIT
		public void WaitcargarIfe(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='radio-toggle']/label[2]/span")));
		}
		
		// CARGAR CEDULA PASAPORTE
		public WebElement cargarPasaporte(WebDriver driver) {
			element = driver.findElement(By.xpath("//*[@id='radio-toggle']/label[3]/span"));
			return element;
		}
		
		// WAIT
		public void WaitcargarPasaporte(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='radio-toggle']/label[3]/span")));
		}
		
		// CARGAR ESTADO CIVIL
		public WebElement civilStatusSelect(WebDriver driver) {
			element = driver.findElement(By.id("civilStatusSelect"));
			return element;
		}
		
		// WAIT
		public void WaitcivilStatusSelect(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("civilStatusSelect")));
		}
		
		// CARGAR VIGENCIA
		public WebElement validitySelect(WebDriver driver) {
			element = driver.findElement(By.id("validitySelect"));
			return element;
		}
		
		// WAIT
		public void WaitvaliditySelect(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("validitySelect")));
		}
		
		// MES VIGENCIA
		public WebElement monthValiditySelect(WebDriver driver) {
			element = driver.findElement(By.id("monthValiditySelect"));
			return element;
		}
		
		// WAIT
		public void WaitmonthValiditySelect(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("monthValiditySelect")));
		}
		
		
		
		//BOTON CONTINUAR
		public WebElement btnContinue(WebDriver driver) {
			element = driver.findElement(By.id("btnContinue"));
			return element;
		}
		
		// WAIT
		public void WaitbtnContinue(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnContinue")));
		}
		
		
		//BOTON REEMPLAZAR
		public WebElement btnReemplazar(WebDriver driver) {
			element = driver.findElement(By.id("//*[@id='helperTarget01Mobile']/div[2]/div/button"));
			return element;
		}
		
		// WAIT
		public void WaitbtnReemplazar(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("//*[@id='helperTarget01Mobile']/div[2]/div/button")));
		}

		

	}