package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LandingPage {

	public static WebElement element = null;
	int secons = 20;

	// BOTON TRAMITAR CREDITO
	public WebElement btnContinue(WebDriver driver) {
		element = driver.findElement(By.id("btnContinue"));
		return element;
	}

	// WAIT
	public void WaitbtnContinue(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnContinue")));
	}

	// CHECK ACEPTO USO DE DATOS
	public WebElement acceptTermsCheckLabel(WebDriver driver) {
		element = driver.findElement(By.id("acceptTermsCheckLabel"));
		return element;
	}

	// WAIT
	public void WaitacceptTermsCheckLabel(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("acceptTermsCheckLabel")));
	}

	// BOTON DE ACEPTO USO DE DATOS
	public WebElement acceptTemrs(WebDriver driver) {
		element = driver.findElement(By.id("acceptTemrs"));
		return element;
	}

	// WAIT
	public void WaitacceptTemrs(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("acceptTemrs")));
	}

}
