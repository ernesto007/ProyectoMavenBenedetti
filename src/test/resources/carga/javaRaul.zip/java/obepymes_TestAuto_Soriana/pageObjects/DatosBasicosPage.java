package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DatosBasicosPage {
	public static WebElement element = null;
	int secons = 20;
	// RFC
	public WebElement rfc(WebDriver driver) {
		element = driver.findElement(By.id("rfc"));
		return element;
	}
	
	// WAIT
	public void Waitrfc(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rfc")));
	}

	// CELULAR
	public WebElement phoneNumberComplete(WebDriver driver) {
		element = driver.findElement(By.id("phoneNumberComplete"));
		return element;
	}
	
	// WAIT
	public void WaitphoneNumberComplete(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("phoneNumberComplete")));
	}

	// COMPA�IA CELULAR
	public WebElement companySelect(WebDriver driver) {
		element = driver.findElement(By.id("companySelect"));
		return element;
	}
	
	// WAIT
	public void WaitcompanySelect(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("companySelect")));
	}
	
	// ENVIAR CODIGO
	public WebElement sendSecurityCode(WebDriver driver) {
		element = driver.findElement(By.id("sendSecurityCode"));
		return element;
	}
	
	// WAIT
	public void WaitsendSecurityCode(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sendSecurityCode")));
	}
	
	// BOTON MODAL ACEPTAR
	public WebElement btnModalAccept(WebDriver driver) {
		element = driver.findElement(By.id("btnModalAccept"));
		return element;
	}
	
	// WAIT
	public void WaitbtnModalAccept(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnModalAccept")));
	}
	
	// CODIGO SEGURIDAD OCULTO
	public WebElement hdnCodeValue(WebDriver driver) {
		element = driver.findElement(By.id("hdnCodeValue"));
		//element.getAttribute("value");
		return element;
	}
	
	// WAIT
	public void WaithdnCodeValue(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdnCodeValue")));
	}
	
	// CODIGO SEGURIDAD
	public WebElement securityCode(WebDriver driver) {
		element = driver.findElement(By.id("securityCode"));
		//element.getAttribute("value");
		return element;
	}
	
	// WAIT
	public void WaitsecurityCode(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("securityCode")));
	}
	
	
	// APELLIDO PATERNO
	public WebElement apellidoPaterno(WebDriver driver) {
		element = driver.findElement(By.id("apellido-paterno"));
		//element.getAttribute("value");
		return element;
	}
	
	// WAIT
	public void WaitapellidoPaterno(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("apellido-paterno")));
	}
	
	// APELLIDO MATERNO
	public WebElement apellidoMaterno(WebDriver driver) {
		element = driver.findElement(By.id("apellido-materno"));
		//element.getAttribute("value");
		return element;
	}
	
	// WAIT
	public void WaitapellidoMaterno(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("apellido-materno")));
	}
	
	
	// NOMBRE
		public WebElement nombre(WebDriver driver) {
			element = driver.findElement(By.id("nombre"));
			//element.getAttribute("value");
			return element;
		}
		
		// WAIT
		public void Waitnombre(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nombre")));
		}
	
		// EMAIL
		public WebElement email(WebDriver driver) {
			element = driver.findElement(By.id("email"));
			//element.getAttribute("value");
			return element;
		}
		
		// WAIT
		public void Waitemail(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
		}
		
		// CONFIRMAR EMAIL
		public WebElement email2(WebDriver driver) {
			element = driver.findElement(By.id("email2"));
			//element.getAttribute("value");
			return element;
		}
		
		// WAIT
		public void Waitemail2(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email2")));
		}
		
		// CONFIRMAR EMAIL
		public WebElement btnContinue(WebDriver driver) {
			element = driver.findElement(By.id("btnContinue"));
			//element.getAttribute("value");
			return element;
		}
		
		// WAIT
		public void WaitbtnContinue(WebDriver driver) {
			WebDriverWait wait = new WebDriverWait(driver, secons);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnContinue")));
		}
	

}
