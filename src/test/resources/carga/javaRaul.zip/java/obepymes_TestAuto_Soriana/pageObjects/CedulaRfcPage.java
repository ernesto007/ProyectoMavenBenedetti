package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CedulaRfcPage {

	public static WebElement element = null;
	int secons = 20;
	
    // CEDULA
    public WebElement ImagenCedulaRfc(WebDriver driver) {
           element = driver.findElement(By.xpath("//*[@id='cedulaFile']"));
           //element.getAttribute("value");
           return element;
    }
    
    // WAIT 
    public void WaitImagenCedulaRfc(WebDriver driver) {
           WebDriverWait wait = new WebDriverWait(driver, secons);
           element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='cedulaFile']")));
    }
	
	
	// ACTIVIDAD ECONOMICA 
	public WebElement ActividadEconomica(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='economicActivity']"));
		return element;
	}
	
	// WAIT
	public void WaitActividadEconomica(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='economicActivity']")));
	}

	// CURP
	public WebElement Curp(WebDriver driver) {
		element = driver.findElement(By.id("curp"));
		return element;
	}
	
	// WAIT
	public void WaitCurp(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("curp")));
	}
	
	// MODAL ACEPTA CURP 
	public WebElement ModalAceptaCurp(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id=\"btnModalAccept\"]"));
		return element;
	}
	
	// WAIT 
	public void WaitModalAceptaCurp(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"btnModalAccept\"]")));
	}
	
	//// MODAL CANCELAR CURP
	//public WebElement ModalCancelarCurp(WebDriver driver) {
		//element = driver.findElement(By.xpath("//*[@id=\"btnModalCancel\"]"));
		//return element;
	//}
	
	// WAIT 
	//public void WaitModalCancelarCurp(WebDriver driver) {
		//WebDriverWait wait = new WebDriverWait(driver, secons);
		//element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"btnModalCancel\"]")));
	//}
	
	// CODIGO POSTAL
	public WebElement CodigoPostal(WebDriver driver) {
		element = driver.findElement(By.id("cp"));
		return element;
	}
	
	// WAIT
	public void WaitCodigoPostal(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cp")));
	}
	
	// BOTON CONTINUAR SIGUIENTE PAGINA
	public WebElement BotonContinuar(WebDriver driver) {
		element = driver.findElement(By.id("btnContinue"));
		//element.getAttribute("value");
		return element;
	}
	
	// WAIT
	public void WaitBotoncontinuar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnContinue")));
	}
	
	
	

}