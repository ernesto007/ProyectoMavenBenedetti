package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ComprobanteDomicilioPage {

	public static WebElement element = null;
	int secons = 20;

	// IMAGEN DE COMPROBANTE DE DOMICILIO ESTADO DE CUENTA
	public WebElement ComprobanteDomicilioEstado(WebDriver driver) {
		element = driver.findElement(By.id("btn-edoCuenta"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitComprobanteDomicilioEstado(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.id("btn-edoCuenta")));
	}
	
	// IMAGEN DE COMPROBANTE DE DOMICILIO RECIBO DE LUZ 
	public WebElement ComprobanteDomicilioLuz(WebDriver driver) {
		element = driver.findElement(By.id("btn-reciboLuz"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitComprobanteDomicilioLuz(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.id("btn-reciboLuz")));
	}
	// IMAGEN DE COMPROBANTE DE DOMICILIO RECIBO TELEFONICO
	public WebElement ComprobanteDomicilioTel(WebDriver driver) {
		element = driver.findElement(By.id("btn-reciboTel"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitComprobanteDomicilioTel(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.id("btn-reciboTel")));
	}

	// SELECCIONA EL ULTIMO MES DE FACTURA
	public WebElement UltimoMesFactura(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='billingMonthSelect']"));
		return element;
	}

	// WAIT
	public void WaitUltimoMesFactura(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='billingMonthSelect']")));
	}

	// SELECCIONA SITUACION DE CASA
	public WebElement SituacionCasa(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='homeSituationSelect']"));
		return element;
	}

	// WAIT
	public void WaitSituacionCasa(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='homeSituationSelect']")));
	}

	// CODIGO POSTAL DE EMPRESA
	public WebElement CodigoPostalEmpresa(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='cpCd']"));
		return element;
	}

	// WAIT
	public void WaitCodigoPostalEmpresa(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='cpCd']")));
	}

	// ASENTAMINETO
	public WebElement Asentamiento(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='typeSettlementSelect']"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitAsentamiento(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='typeSettlementSelect']")));
	}

	// COLONIA
	public WebElement Colonia(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='colonySelect']"));
		return element;
	}

	// WAIT
	public void WaitColonia(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='colonySelect']")));
	}

	// VIALIDAD
	public WebElement Vialidad(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='typeStreetSelect']"));
		return element;
	}

	// WAIT
	public void WaitVialidad(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='typeStreetSelect']")));
	}

	// CALLE
	public WebElement Calle(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='street']"));
		return element;
	}

	// WAIT
	public void WaitCalle(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='street']")));
	}

	// NUMERO EXTERIOR
	public WebElement NumExt(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='extNo']"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitNumExt(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='extNo']")));
	}

	// NUMERO INTERIOR
	public WebElement NumInt(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='intNo']"));
		return element;
	}

	// WAIT
	public void WaitNumInt(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='intNo']")));
	}

	// ENTRE CALLE
	public WebElement EntreCalle(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='between']"));
		return element;
	}

	// WAIT
	public void WaitEntreCalle(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='between']")));
	}

	// Y ENTRE QUE CALLE
	public WebElement YentreCalle(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='andBetween']"));
		return element;
	}

	// WAIT
	public void WaitYentreCalle(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='andBetween']")));
	}

	// Y ENTRE QUE CALLE
	public WebElement RevisarDatosAnterior(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnPrevPage']"));
		return element;
	}

	// WAIT
	public void WaitRevisarDatosAnterior(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnPrevPage']")));
	}

	// Y ENTRE QUE CALLE
	public WebElement RegresarDatos(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnNextPage']"));
		return element;
	}

	// WAIT
	public void WaitRegresarDatos(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnNextPage']")));
	}

	// BOOTN CONTINUAR
	public WebElement Botoncontinuar(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnContinue']"));
		return element;
	}

	// WAIT
	public void WaitBotoncontinuar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnContinue']")));
	}

	// BOOTN REGRESAR
	public WebElement BotonRegresar(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnPrevPage']"));
		return element;
	}

	// WAIT
	public void WaitBotonRegresar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnPrevPage']")));
	}

	// BOOTN VOLVER
	public WebElement BotonVolver(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnNextPage']"));
		return element;
	}

	// WAIT
	public void WaitBotonVolver(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnNextPage']")));
	}
}
