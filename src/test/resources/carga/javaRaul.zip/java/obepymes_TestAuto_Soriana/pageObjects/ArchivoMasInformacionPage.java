package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ArchivoMasInformacionPage {

	public static WebElement element = null;
	int secons = 20;


	// TE MUESTRA MAS INFORMACION SOBRE TU CUENTA DESCARGANDO UN PDF
	public WebElement MuestraMasInfo(WebDriver driver) {
		element = driver.findElement(By.xpath("html/body/div[4]/div/div[3]/div/div[5]/div/div/a"));
		return element;
	}

	// WAIT
	public void WaitMuestraMasInfo(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("html/body/div[4]/div/div[3]/div/div[5]/div/div/a")));
	}

	// BOTON DE ACEPTAR 
	public WebElement BotonContinuar(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnContinuar']"));
		return element;
	}

	// WAIT
	public void WaitBotonContinuar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnContinuar']")));
	}

}