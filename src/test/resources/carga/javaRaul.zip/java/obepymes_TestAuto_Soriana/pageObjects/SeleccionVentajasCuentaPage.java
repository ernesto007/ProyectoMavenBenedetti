package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleccionVentajasCuentaPage {

	public static WebElement element = null;
	int secons = 20;

	// SELECCIONA LAS VENTAJAS QUE TE INTERESARIA TENER PARA TU CUENTA (Credito
	// PYME)
	public WebElement CheckCreditoPyme(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='checkbox2']"));
		return element;
	}

	// WAIT
	public void WaitCheckCreditoPyme(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='checkbox2']")));
	}

	// SELECCIONA LAS VENTAJAS QUE TE INTERESARIA TENER PARA TU CUENTA (Tarjeta
	// de Credito)
	public WebElement CheckTarjetaCredito(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='checkbox1']"));
		return element;
	}

	// WAIT
	public void WaitCheckTarjetaCredito(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='checkbox1']")));
	}

	// SELECCIONA LAS VENTAJAS QUE TE INTERESARIA TENER PARA TU CUENTA (Terminal
	// Punto de Venta)
	public WebElement CheckTerminalPuntoVenta(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='checkbox3']"));
		return element;
	}

	// WAIT
	public void WaitCheckTerminalPuntoVenta(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='checkbox3']")));
	}



	// SELECCIONA LAS VENTAJAS QUE TE INTERESARIA TENER PARA TU CUENTA (Nomina)
	public WebElement CheckNomina(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='checkbox5']"));
		return element;
	}

	// WAIT
	public void WaitCheckNomina(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='checkbox5']")));
	}

	// SELECCIONA LAS VENTAJAS QUE TE INTERESARIA TENER PARA TU CUENTA (Nomina)
	public WebElement CheckPagoImpuestos(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='checkbox4']"));
		return element;
	}

	// WAIT
	public void WaitCheckPagoImpuestos(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='checkbox4']")));
	}

	// BOTON DE ACEPTAR RESUMEN DE CITA
	public WebElement BotonContinuar(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnContinuar']"));
		return element;
	}

	// WAIT
	public void WaitBotonContinuar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnContinuar']")));
	}

}
