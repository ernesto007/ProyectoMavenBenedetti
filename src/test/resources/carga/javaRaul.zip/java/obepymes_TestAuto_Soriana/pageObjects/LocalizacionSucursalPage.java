package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LocalizacionSucursalPage {

	public static WebElement element = null;
	int secons = 20;

	// SELECCIONA BUSCAR SUCURSAL
	public WebElement BuscaSucursal(WebDriver driver) {
		element = driver.findElement(By.id("searchLocationInput"));
		// element.getAttribute("value");
		return element;
	}

	// WAIT
	public void WaitBuscaSucursal(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchLocationInput")));
	}

	// SELECCIONA SUCURSAL DESEADA
	public WebElement SeleccionarSucursal(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='oficinas']/div[2]/a/div/div[2]/p[1]"));
		return element;
	}

	// WAIT
	public void WaitSeleccionarSucursalFactura(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//*[@id='oficinas']/div[2]/a/div/div[2]/p[1]")));
	}

	// SELECCIONA SUCURSAL DESEADA
	public WebElement BotonDeContinuar(WebDriver driver) {
		element = driver.findElement(By.id("btnContinue"));
		return element;
	}

	// WAIT
	public void WaitBotonDeContinuar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnContinue")));
	}

}
