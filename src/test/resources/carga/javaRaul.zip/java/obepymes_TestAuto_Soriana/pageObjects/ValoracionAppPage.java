package obepymes_TestAuto_Soriana.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ValoracionAppPage {

	public static WebElement element = null;
	int secons = 20;

	// TE PERMITE HACER TU CALIFICACION DE LA APP
	public WebElement ElementoParaCalificar(WebDriver driver) {
		element = driver.findElement(By.xpath("html/body/div[4]/div/div[2]/div[1]/div[2]/div/span/i[5]"));
		return element;
	}

	// WAIT
	public void WaitElementoParaCalificar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("html/body/div[4]/div/div[2]/div[1]/div[2]/div/span/i[5]")));
	}

	// BOTON DE ACEPTAR
	public WebElement BotonContinuar(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnContinuar']"));
		return element;
	}

	// WAIT
	public void WaitBotonContinuar(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnContinuar']")));
	}

	// MODAL DE FINALIZO REGISTRO DE CITA
	public WebElement BotonModalFinalizoCita(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id='btnModalAccept']"));
		return element;
	}

	// WAIT
	public void WaitModalFinalizoCita(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, secons);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnModalAccept']")));
}
}
