package obepymes_TestAuto_Soriana.validation;

import org.openqa.selenium.WebDriver;

import obepymes_TestAuto_Soriana.pageObjects.LandingPage;

public class validationLanding {

	LandingPage elementsLanding = new LandingPage();

	public boolean ValLanding(WebDriver driver) {
		boolean valbtnContinue;
		boolean result;
		
		// VALIDA INICIAR TRAMITE
		try {
			valbtnContinue = elementsLanding.btnContinue(driver).isDisplayed();
		} catch (Exception ex) {
			valbtnContinue = false;
		}

		if (valbtnContinue) {
			result = true;

		} else {
			result = false;
		}

		return result;
	}

}
